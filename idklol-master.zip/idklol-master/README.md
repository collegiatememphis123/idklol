# idklol
This is me (richard) showing I how how to commit and push 

and this is gerardo not knowing what he is doing

#This is Tae 💩
